# Curah hujan harian SILO — 15 stasiun, 1926–2025

Periode: 1 Januari 1926–31 Desember 2025 (100 tahun penuh).
Sumber: Queensland Government SILO, Patched Point Dataset, variabel daily_rain (mm).
Tanggal permintaan: 25 Oktober 2026. Tanggal ekstraksi server tercantum dalam metadata dan JSON asli.

## Isi paket

- `per_station/`: 15 CSV, satu per stasiun.
- `rainfall_all_15_stations_1926_2025.csv`: seluruh data dalam format panjang, satu baris per tanggal-stasiun.
- `station_metadata_and_completeness.csv`: ID, nama, koordinat, elevasi, dan proporsi jenis sumber tiap stasiun.
- `observation_coverage_by_year.csv`: jumlah pengamatan resmi, redistribusi, dan interpolasi per tahun-stasiun.
- `source_codes.csv`: arti kode sumber.
- `raw/`: respons JSON asli SILO, disimpan untuk penelusuran.
- `validation.json`: hasil pemeriksaan kelengkapan.
- `SHA256SUMS.txt`: checksum file dalam paket.

## Definisi kolom data

`date`: tanggal ISO YYYY-MM-DD sesuai respons SILO; tidak digeser atau dikonversi zona waktu.
`station_id`: nomor stasiun BoM, ditulis dengan enam digit (simpan sebagai teks untuk mempertahankan nol awal).
`station_name`: nama stasiun dari SILO.
`location`: label daerah untuk pengelompokan.
`rainfall_mm`: curah hujan harian dalam milimeter, nilai asli SILO tanpa pembulatan tambahan.
`source_code`: kode asal nilai dari SILO.
`source_type`: label kode sumber.

Kode 0 = pengamatan resmi BoM pada stasiun tersebut; 23 = pengamatan BoM dari stasiun tetangga; 13 = hujan akumulasi yang dialokasikan kembali menggunakan stasiun tetangga; 15 = hujan akumulasi yang dialokasikan kembali menggunakan interpolasi; 25 = interpolasi pengamatan harian; 35 = interpolasi anomali; 75 = interpolasi rerata jangka panjang. Kode 13 dan 15 tidak dihitung sebagai pengamatan harian langsung. Persentase pengamatan resmi hanya menghitung kode 0, dengan penyebut seluruh hari dalam periode. Kode 23 dilaporkan terpisah. Definisi tambahan kode 13 dan 23 diverifikasi dari bagian catatan respons API resmi dalam format alldata.

## Pemilihan dan batas penggunaan

Satu stasiun dipilih untuk masing-masing 15 daerah yang disepakati. Label iklim merupakan deskripsi geografis umum untuk pemilihan, bukan klasifikasi Koppen yang dihitung dari dataset. Paket ini tidak mengklaim berisi 15 stasiun dengan persentase pengamatan tertinggi di seluruh Australia. Pengunduh tidak menyambung stasiun dengan stasiun pengganti; setiap seri mempertahankan satu ID SILO. SILO sendiri dapat menggunakan pengamatan stasiun tetangga, ditandai kode 23.

Deret lengkap 100 tahun mencakup interpolasi ketika pengamatan tidak tersedia, termasuk sebelum stasiun dibuka atau sesudah pengamatan berhenti. Tanggal pertama/terakhir pengamatan pada metadata hanya berlaku di dalam periode 1926–2025; bukan tanggal pembukaan/penutupan stasiun. Periksa cakupan tahunan sebelum menentukan periode analisis.

SILO menyatakan produknya tidak ditujukan untuk studi deteksi perubahan iklim. Deret lengkap tidak berarti deret homogen atau seluruh nilainya hasil pengamatan langsung.

## Sumber dan atribusi

Data: Queensland Government SILO, dibangun dari pengamatan Australian Bureau of Meteorology dan pemasok terkait. Lisensi CC BY 4.0: https://creativecommons.org/licenses/by/4.0/

- SILO: https://www.longpaddock.qld.gov.au/silo/
- API: https://www.longpaddock.qld.gov.au/silo/api-documentation/reference/
- Kode sumber: https://www.longpaddock.qld.gov.au/silo/about/about-data/
- Variabel dan satuan: https://www.longpaddock.qld.gov.au/silo/about/climate-variables/

Parameter permintaan: `station=<station_id>&start=19260101&finish=20251231&format=json&comment=R&username=<email pemohon>` pada endpoint `https://www.longpaddock.qld.gov.au/cgi-bin/silo/PatchedPointDataset.php`.

CSV dihasilkan dengan menyalin tanggal, nilai, dan kode sumber dari JSON asli; tidak dilakukan pengisian data tambahan oleh pengunduh.
